# Zou Jiale — Personal Portfolio

React + Vite + GSAP portfolio site generated from the supplied 75-page PDF.
The PDF artwork is preserved as complete page images; motion is applied only to
the surrounding web presentation.

## Local development

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

## Production build

```bash
npm run build
npm run preview
```

The production build is written to `dist/`.
